# mini.cur
 A small cursor set for Windows

![Preview](https://raw.githubusercontent.com/rghv234/mini.cur/master/Size%20Compared%20to%20a%20Folder.JPG)

# Instructions to Install :
Clone or Download file first
# Manual Method

1. Open Control Panel
2. Choose Hardware and Sound
3. Navigate to Devices and Printers
4. Choose Mouse
5. Mouse Properties window appears
6. Select Pointers Tab
7. Click on Browse
8. Select all the respective cursors one by one.
9. Click 'Apply' and then 'OK'

       OR
# Automatic Method

1. Select 'Install.inf' file
2. Right-Click and click 'Install'
3. Follow the steps in Manual Method and open Mouse Properties window
4. Go to Pointers Tab 
5. In the Scheme section click on dropdown menu and select mini.cur
6. Click 'Apply' and then click 'OK'


 	 

